<?php

class Item
{
    private string $nickname;
    private int $tamanho;
    private string $classe;

    public function __construct($nickname, $tamanho, $classe)
    {
        $this->setNickname($nickname);
        $this->setTamanho($tamanho);
        $this->setClasse($classe);
    }

    public function getNickname(): string
    {
        return $this->nickname;
    }

    public function setNickname(string $nickname): void
    {
        if (empty($nickname)) {
            $this->nickname = "Informe um nome válido";
        } else {
            $this->nickname = $nickname;
        }
    }

    public function getTamanho(): int
    {
        return $this->tamanho;
    }

    public function setTamanho(int $tamanho): void
    {
        if ($tamanho < 0) {
            $this->tamanho = 0;
        } else {
            $this->tamanho = $tamanho;
        }
    }

    public function getClasse(): string
    {
        return $this->classe;
    }

    public function setClasse(string $classe): void
    {
        if (empty($classe)) {
            $this->classe = "Informe uma classe válida";
        } else {
            $this->classe = $classe;
        }
    }
}
